//
//  AlarmController.swift
//  Alarm
//
//  Created by Hin Wong on 3/2/20.
//  Copyright © 2020 Hin Wong. All rights reserved.
//

import UIKit
import UserNotifications


class AlarmController {
    
    var alarms: [Alarm] = []
    
    static let shared = AlarmController()
    
    init() {
        loadFromPersistentStore()
    }
    
    func addAlarm(fireDate:Date, name:String, enabled:Bool){
        
        //Create the alarm
        let alarm = Alarm(fireDate: fireDate, name: name, enabled: enabled, uuid: UUID().uuidString)
        alarms.append(alarm)
        saveToPersistentStore()
    }
    func update(alarm:Alarm, fireDate:Date, name:String, enabled:Bool) {
        alarm.fireDate = fireDate
        alarm.name = name
        alarm.enabled = enabled
        saveToPersistentStore()
    }
    func delete(alarm:Alarm) {
        guard let index = alarms.firstIndex(of: alarm) else {return}
        alarms.remove(at: index)
        saveToPersistentStore()
    }
    func fileURL() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentDirectory = paths[0]
        let filename = "alarm.json"
        let fullURL = documentDirectory.appendingPathComponent(filename)
        return fullURL
    }
    func saveToPersistentStore() {
        let encoder = JSONEncoder()
        do {
            let data = try encoder.encode(alarms)
            try data.write(to: fileURL())
        } catch let error {
            print(error)
        }
    }
    func loadFromPersistentStore() {
        let decoder = JSONDecoder()
        do {
            let data = try Data(contentsOf: fileURL())
            let alarms = try decoder.decode([Alarm].self, from: data)
            self.alarms = alarms
        } catch let error {
            print(error)
        }
    }
    static func toggleEnabled(for alarm:Alarm) {
        alarm.enabled = !alarm.enabled
    }
    
} // Class end

protocol AlarmScheduler {
    func scheduleUserNotifications(for alarm: Alarm)
    func cancelUserNotifications(for alarm: Alarm)
}

extension AlarmScheduler {
    func scheduleUserNotifications(for alarm: Alarm) {
        
        let notificationContent = UNMutableNotificationContent()
        notificationContent.title = "Time's up!"
        notificationContent.body = "Your alarm titled \(alarm.name) is done"
        notificationContent.sound = UNNotificationSound.default
        
        let fireDate = alarm.fireDate 
        let triggerDate = Calendar.current.dateComponents([.hour, .minute, .second], from: fireDate)
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerDate, repeats: true)
        
        let request = UNNotificationRequest(identifier: alarm.uuid, content: notificationContent, trigger: trigger)
        UNUserNotificationCenter.current().add(request) { (error) in
            if error != nil {
                print("error")
            }
        }
    }
    func cancelUserNotifications(for alarm: Alarm) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [alarm.uuid])
    }

}
    
