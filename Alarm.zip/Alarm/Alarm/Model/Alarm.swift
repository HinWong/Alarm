//
//  Alarm.swift
//  Alarm
//
//  Created by Hin Wong on 3/2/20.
//  Copyright © 2020 Hin Wong. All rights reserved.
//

import Foundation

class Alarm:Codable{
    
    var fireDate:Date
    var name:String
    var enabled:Bool
    var uuid:String
    
    init(fireDate:Date = Date(), name:String, enabled:Bool, uuid:String = UUID().uuidString) {
        self.fireDate = fireDate
        self.name = name
        self.enabled = enabled
        self.uuid = uuid
    }
    
    var fireTimeAsString: String {
        get{
            return "\(self.fireDate)"
        }
    }
}

extension Alarm: Equatable {
    static func == (lhs: Alarm, rhs: Alarm) -> Bool {
        return lhs.fireDate == rhs.fireDate &&
            lhs.name == rhs.name &&
            lhs.enabled == rhs.enabled
    }
    
    
}
