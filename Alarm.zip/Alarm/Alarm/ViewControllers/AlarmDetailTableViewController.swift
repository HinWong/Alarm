//
//  AlarmDetailTableViewController.swift
//  Alarm
//
//  Created by Hin Wong on 3/2/20.
//  Copyright © 2020 Hin Wong. All rights reserved.
//

import UIKit

class AlarmDetailTableViewController: UITableViewController {
   
    
    
    var alarmIsOn: Bool = true
    var alarm: Alarm? {
        didSet {
            alarmIsOn = alarm?.enabled ?? true
            loadViewIfNeeded()
            updateViews()
        }
    }
    
    @IBAction func saveButtonTapped(_ sender: Any) {
        if let alarmTitle = alarmName.text {
            if let dateTitle = datePicker?.date {
                if let alarm = alarm {
                    AlarmController.shared.update(alarm: alarm, fireDate: dateTitle, name: alarmTitle, enabled: alarmIsOn)
                } else {
                    AlarmController.shared.addAlarm(fireDate: dateTitle, name: alarmTitle, enabled: alarmIsOn)
                }
                navigationController?.popViewController(animated: true)
            }
        }
    }
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var alarmName: UITextField!
    @IBAction func enabledButtonTapped(_ sender: Any) {
        alarmIsOn = !alarmIsOn
        updateViews()
        updateAlarm()
    }
    @IBOutlet weak var enableButton: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func updateViews () {
        guard let alarm = self.alarm else { return }
        datePicker.setDate(alarm.fireDate, animated: false)
        alarmName.text = alarm.name
    }
    
    func updateAlarm(){
        if alarmIsOn {
            enableButton.setTitle("Turn off", for: .normal)
        }
        else {
            enableButton.setTitle("Turn on", for: .normal)
        }
    }
    

}
