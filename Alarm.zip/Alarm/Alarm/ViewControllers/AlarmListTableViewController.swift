//
//  AlarmListTableViewController.swift
//  Alarm
//
//  Created by Hin Wong on 3/2/20.
//  Copyright © 2020 Hin Wong. All rights reserved.
//

import UIKit

class AlarmListTableViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return AlarmController.shared.alarms.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "alarmCell", for: indexPath) as? SwitchTableViewCell else {return UITableViewCell()}

        let alarm = AlarmController.shared.alarms[indexPath.row]
        cell.alarm = alarm
        cell.updateViews()
        cell.delegate = self
        
        
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
    if editingStyle == .delete {
        //Find what quote the user is trying to delete
        let alarmToDelete = AlarmController.shared.alarms[indexPath.row]
        //Delete it
        AlarmController.shared.delete(alarm: alarmToDelete)
        //Remove quote from the tableview
        tableView.deleteRows(at: [indexPath], with: .fade)
    }
}
}
// Step 3 - Conform to protocol

extension AlarmListTableViewController: SwitchTableViewCellDelegate {
    func switchCellSwitchValueChanged(cell: SwitchTableViewCell, isEnabled:Bool) {
        guard let index = tableView.indexPath(for: cell) else {return}
        let alarm = AlarmController.shared.alarms[index.row]
        AlarmController.toggleEnabled(for: alarm)
        cell.updateViews()
        
    }
    
    
}
