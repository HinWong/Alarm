//
//  SwitchTableViewCell.swift
//  Alarm
//
//  Created by Hin Wong on 3/2/20.
//  Copyright © 2020 Hin Wong. All rights reserved.
//

import UIKit

protocol SwitchTableViewCellDelegate:class {
    func switchCellSwitchValueChanged(cell:SwitchTableViewCell, isEnabled:Bool)
}

class SwitchTableViewCell: UITableViewCell {
    
    // MARK:- Outlets
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var alarmSwitch: UISwitch!
    
    weak var delegate: SwitchTableViewCellDelegate?
    
    //Landing pad
    var alarm:Alarm?
    
    

    //MARK:- Actions
    
    @IBAction func switchValueChanged(_ sender: Any) {
        delegate?.switchCellSwitchValueChanged(cell:self, isEnabled: alarmSwitch.isOn)
    }
    
    // MARK:- Helper methods
    func updateViews() {
        guard let alarm = alarm else {return}
        
        timeLabel.text = alarm.fireTimeAsString
        nameLabel.text = alarm.name
    }
    
}
